/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/17 21:03:25 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/30 02:47:53 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	if (c > 255)
		c = c - 256;
	while (s)
	{
		if (*s == c)
		{
			return ((char *)s);
		}
		if (*s == '\0')
		{
			return (NULL);
		}
	s++;
	}
	return (NULL);
}
