/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/18 00:24:02 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/30 02:47:27 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	while ((unsigned char *)s && n--)
	{
		if (*(unsigned char *)s == (unsigned char)c)
			return ((void *)s);
	s++;
	}
	return (NULL);
}
