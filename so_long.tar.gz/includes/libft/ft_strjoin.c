/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/15 17:31:37 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/30 02:48:01 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*dst;
	int		x;

	x = 0;
	dst = (char *)malloc(((ft_strlen(s1) + ft_strlen(s2)) + 1) * sizeof(char));
	if (!dst)
		return ("NULL");
	while (*s1)
	{
		dst[x] = (char)*s1;
		s1++;
		x++;
	}
	while (*s2)
	{
		dst[x] = (char)*s2;
		s2++;
		x++;
	}
	dst[x] = '\0';
	return (dst);
}
