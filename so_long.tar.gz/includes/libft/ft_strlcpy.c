/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/15 20:24:03 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/29 17:48:26 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	ft_cpy(char *dst, const char *src, int x)
{
	int	i;

	i = 0;
	while (i < x)
	{
		dst[i] = (char)src[i];
		i++;
	}
	dst[i] = '\0';
}

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	int		x;
	int		sizesrc;

	x = (int)size;
	sizesrc = ft_strlen ((char *)src);
	if (size == 0)
		return (sizesrc);
	if (x < 0)
	{
		ft_cpy (dst, (char *)src, sizesrc);
		return (sizesrc);
	}
	if (x > sizesrc)
		x = (sizesrc + 1);
	ft_cpy (dst, (char *)src, (x - 1));
	return (sizesrc);
}
