/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/17 23:59:41 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/30 02:48:12 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_strncmp(const char *s1, const char *s2, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
		if (s1[i] != s2[i])
		{
			if (s1[i] < 0)
				return ((s1[i] * -1) - s2[i]);
			if (s2[i] < 0)
				return (s1[i] - (s2[i] * -1));
			return (s1[i] - s2[i]);
		}
	i++;
	}
	return (0);
}
