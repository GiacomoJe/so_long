/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/17 23:31:05 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/28 18:26:26 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	char	ch;
	int		len;

	ch = c;
	len = ft_strlen((char *)s) - 1;
	if (ch == '\0')
		return ((char *)(s + len + 1));
	while (len >= 0)
	{
		if (*(s + len) == ch)
		{
			return ((char *)(s + len));
		}
		len--;
	}
	return (0);
}
