/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/13 23:38:55 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/05/30 02:48:21 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	len_s;
	char	*src;

	len_s = ft_strlen(s);
	if (!s)
		return (0);
	if (len_s <= start)
	{
		src = (char *)malloc(1);
		src[0] = '\0';
		return (src);
	}
	else if (len <= len_s - start)
		src = (char *)malloc((len + 1) * sizeof(char));
	else
		src = (char *)malloc((len_s - start + 1) * sizeof(char));
	if (!src)
		return (0);
	ft_strlcpy(src, s + start, len + 1);
	return (src);
}
