/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jgiacomo <jefersongiacomo@gmail.com>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 01:09:10 by jgiacomo          #+#    #+#             */
/*   Updated: 2022/06/26 17:43:31 by jgiacomo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char	*ft_addbuffer(char *buffer, char *str)
{
	char	*temp;

	temp = ft_strjoin(buffer, str);
	free(buffer);
	return (temp);
}

static char	*find_end_line(int fd, char *str)
{
	int		line_finded;
	char	*buffer;

	if (!str)
		str = ft_calloc(1, 1);
	line_finded = 1;
	buffer = ft_calloc(BUFFER_SIZE + 1, sizeof(char));
	while (line_finded > 0)
	{
		line_finded = read(fd, buffer, BUFFER_SIZE);
		if (line_finded == -1)
		{
			free(buffer);
			return (NULL);
		}
		buffer[line_finded] = '\0';
		str = ft_addbuffer(str, buffer);
		if (ft_strchr(buffer, 10))
			line_finded = 0;
	}
	free(buffer);
	return (str);
}

static char	*ft_restline(char *line)
{
	int		i;
	int		x;
	char	*temp;

	x = 0;
	i = 0;
	while (line[i] != 10 && line[i])
		i++;
	if (!line[i])
	{
		free(line);
		return (NULL);
	}
	i++;
	while (line[i + x])
		x++;
	temp = ft_calloc(x + 1, sizeof(char));
	x = 0;
	while (line[i + x])
	{
		temp[x] = line[i + x];
		x++;
	}
	free(line);
	return (temp);
}

static char	*ft_line_rtn(char *buffer_line)
{
	char	*temp;
	int		i;

	i = 0;
	if (!buffer_line[i])
		return (NULL);
	while (buffer_line[i] && buffer_line[i] != 10)
		i++;
	temp = ft_calloc(i + 2, sizeof(char));
	i = 0;
	while (buffer_line[i] && buffer_line[i] != 10)
	{
		temp[i] = buffer_line[i];
		i++;
	}
	if (buffer_line[i] && buffer_line[i] == 10)
		temp[i++] = 10;
	return (temp);
}

char	*get_next_line(int fd)
{
	static char	*buffer_line;
	char		*str_rtn;

	if (fd < 0 || read(fd, 0, 0) < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	buffer_line = find_end_line(fd, buffer_line);
	if (!buffer_line)
		return (NULL);
	str_rtn = ft_line_rtn(buffer_line);
	buffer_line = ft_restline(buffer_line);
	return (str_rtn);
}
